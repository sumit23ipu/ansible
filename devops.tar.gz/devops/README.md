# devops
Please add all devops docs, exercises even the links which might help us learn new things here 

cmdAll file contains the command history which can help you to get the command needed to execute
